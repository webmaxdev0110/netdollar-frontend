<?php

class TaskBase extends Phalcon\CLI\Task
{

}