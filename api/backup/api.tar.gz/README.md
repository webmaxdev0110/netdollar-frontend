**After** [ `make build` ] **dont forget to run:**
[ `make indexes` ] .

_**IT'S NECESSARY!!!**_